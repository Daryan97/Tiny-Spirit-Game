#ifndef MAPS_HPP
#define MAPS_HPP

#include "enemy.cpp"

    class Map
    {
        private:
            int x = 0;
            int y = 0;
            const unsigned int width = 32, height = 32;
            int level = 0;
            char* grassTile;
            char* heartCollectible;
            int** map;
            int mapTilesCount;
            Enemy* enemies;
            int enemiesCount = 0;
        public:
            int posX() {return x;}
            int posY() {return y;}
            int** getMap() {return map;}
            int getMapTilesCount() {return mapTilesCount;}
            int getLevel() {return level;}
            Enemy* getEnemies() {return enemies;}
            int getEnemiesCount() {return enemiesCount;}
            void readMapAssets();
            void placeTiles();
            void placeEnemies();
            void setLevel(int level);
};

#endif