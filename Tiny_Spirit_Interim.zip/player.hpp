#ifndef PLAYER_HPP
#define PLAYER_HPP
#include "Maps.cpp"

    class Player : public Map
    {
        private:
		    int max_health = 3;
		    int health = 2;
            int x = 150;
            int y = 500;
            double speed = 3;
            bool lookingRight = true;
            bool isJumping = false;
    		bool isOnGround = true;
	    	const unsigned int width = 32, height = 32;
		    char* playerRight;
    		char* playerLeft;
	    	char* playerWalkingRight;
		    char* playerWalkingLeft;
    		char* playerEmptyHeart;
	    	char* playerFullHeart;
			int enemyTouchCount = 0;
        public:
            int posX() {return x;}
            int posY() {return y;}
	    	int getHealth() {return health;}
			int getTouchCount() {return enemyTouchCount;}
			void setTouchCount(int count) {this->enemyTouchCount = enemyTouchCount + count;}
		    void setPosX(int x) {this->x = x;}
    		void setPosY(int y) {this->y = y;}
            void playerActions(int x, int y);
		    void readPlayerAssets();
    		void playerJump();
	    	void playerHealth(int health);
		    void playerCollision();
		    void setHealthbar();
			bool playerTouchEnemy();
			void registerTouchCount();
    		Player(int level)
	    	{
		    	setLevel(level);
		    }
    };

#endif