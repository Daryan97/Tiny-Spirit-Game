#include <graphics.h>
#include <iostream>
#include "player.cpp"

using namespace std;

	int screenWidth = 800;
    int screenHeight = 600;

int main()
{
    initwindow(screenWidth, screenHeight, "Tiny Spirit");
	char* background = new char[imagesize(0, 0, screenWidth, screenHeight)];
	readimagefile("Assets/Map/bg.gif", 0, 0, screenWidth, screenHeight);
	getimage(0, 0, screenWidth, screenHeight, background);

    int page = 0;
    Player player(1);
    player.readPlayerAssets();
    while(true)
    {
        setactivepage(page);
        setvisualpage(1 - page);
        cleardevice();
        
        putimage(0, 0, background, COPY_PUT);
        player.placeTiles();
        player.placeEnemies();

        player.playerActions(player.posX(), player.posY());
        player.playerJump();
        
        page = 1 - page;
        delay(5);
    }
}