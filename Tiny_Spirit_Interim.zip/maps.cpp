#include <graphics.h>
#include <iostream>
#include "maps.hpp"

using namespace std;


void Map::readMapAssets() {
    grassTile = new char[imagesize(0, 0, width, height)];
    readimagefile("Assets/Map/grassTile.gif", 0, 0, width, height);
    getimage(0, 0, width, height, grassTile);

    heartCollectible = new char[imagesize(0, 0, width, height)];
    readimagefile("Assets/Map/Collectibles/heart.gif", 0, 0, width, height);
    getimage(0, 0, width, height, heartCollectible);
}

void Map::setLevel(int level) {
    if (level == 1) {
        this->level = level;
        this->mapTilesCount = 27;
        this->map = new int*[mapTilesCount];
        for (int i = 0; i < this->mapTilesCount; i++) {
            this->map[i] = new int[3];
            this->map[i][0] = i * 32;
            this->map[i][1] = 568;
            this->map[i][2] = 0;
        }

        this->map[25][0] = 300;
        this->map[25][1] = 536;
        this->map[25][2] = 0;
        this->map[26][0] = 300;
        this->map[26][1] = 500;
        this->map[26][2] = 1;


        // create enemies
        this->enemiesCount = 1;
        this->enemies = new Enemy[enemiesCount];
        enemies[0] = Enemy(715, 536, 575, 715);

        for(int i = 0; i < enemiesCount; i++) {
            enemies[i].readEnemyAssets();
        }
    }
}

void Map::placeTiles() {
    for(int i = 0; i < mapTilesCount; i++) {
        if(map[i][2] == 0) {
            putimage(map[i][0], map[i][1], grassTile, COPY_PUT);
        } else if(map[i][2] == 1) {
            putimage(map[i][0], map[i][1], heartCollectible, COPY_PUT);
        }
    }
}

void Map::placeEnemies() {
    for(int i = 0; i < enemiesCount; i++) {
        enemies[i].drawEnemy();
    }
}