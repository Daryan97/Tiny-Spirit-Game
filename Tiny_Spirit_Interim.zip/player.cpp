#include <graphics.h>
#include <iostream>
#include "player.hpp"
using namespace std;

void Player::readPlayerAssets() {
	playerRight = new char[imagesize(0, 0, width, height)];
	readimagefile("Assets/Player/player_right.gif", 0, 0, width, height);
	getimage(0, 0, width, height, playerRight);

	playerLeft = new char[imagesize(0, 0, width, height)];
	readimagefile("Assets/Player/player_left.gif", 0, 0, width, height);
	getimage(0, 0, width, height, playerLeft);

	playerWalkingRight = new char[imagesize(0, 0, width, height)];
	readimagefile("Assets/Player/Walking/player_right_1.gif", 0, 0, width, height);
	getimage(0, 0, width, height, playerWalkingRight);


	playerWalkingLeft = new char[imagesize(0, 0, width, height)];
	readimagefile("Assets/Player/Walking/player_left_1.gif", 0, 0, width, height);
	getimage(0, 0, width, height, playerWalkingLeft);

	playerEmptyHeart = new char[imagesize(0, 0, width, height)];
	readimagefile("Assets/Player/empty_heart.gif", 0, 0, width, height);
	getimage(0, 0, width, height, playerEmptyHeart);

	playerFullHeart = new char[imagesize(0, 0, width, height)];
	readimagefile("Assets/Player/full_heart.gif", 0, 0, width, height);
	getimage(0, 0, width, height, playerFullHeart);

	readMapAssets();
}

void Player::playerActions(int x, int y) {
    if(GetAsyncKeyState(VK_RIGHT))
	{
		putimage(this->x, this->y, playerWalkingRight, COPY_PUT);
		this->x += speed;
		lookingRight = true;
	}
	else if(GetAsyncKeyState(VK_LEFT))
	{
		putimage(this->x, this->y, playerWalkingLeft, COPY_PUT);
		this->x -= speed;
        this->lookingRight = false;
	}
	else {
    	if (lookingRight == true)
    	{
			putimage(this->posX(), this->posY(), playerRight, COPY_PUT);
    	}
    	else
    	{
			putimage(this->posX(), this->posY(), playerLeft, COPY_PUT);
    	}
	}


	registerTouchCount();
	if(this->enemyTouchCount == 17) {
		this->enemyTouchCount = 0;
		playerHealth(-1);
	}

	// debug options (will be removed later)
	if(ismouseclick(WM_LBUTTONDOWN)) {
		setPosX(mousex());
		setPosY(mousey() - 32);
		clearmouseclick(WM_LBUTTONDOWN);
	} else {
		setPosY(y + 1);
		playerCollision();
		setHealthbar();
	}

	// debug options (will be removed later)
	if (GetAsyncKeyState(VK_LSHIFT)) {
		cout << "Player X: " << this->x << endl;
		cout << "Player Y: " << this->y << endl;
	}

	// debug options (will be removed later)
	cout << "Touch count: " << this->enemyTouchCount << endl;

	if (getHealth() <= 0) {
		cout << "Game over!" << endl;
		exit(0);
	}
}

void Player::playerJump() {
	if((GetAsyncKeyState(VK_SPACE) || GetAsyncKeyState(VK_UP)) && (isJumping != true))
	{
		isJumping = true;
	}

	if (isJumping == true && isOnGround == true)
	{
		isOnGround = false;
		setPosY(y - 40);
	}
}

void Player::playerCollision() {
	// player bounding
	int playerLeft = this->x;
	int playerRight = this->x + width;
	int playerTop = this->y;
	int playerBottom = this->y + height;

	// player cannot go out of bounds
	if (posX() < 0) {
		setPosX(0);
	}
	else if (posX() > (800 - width)) {
		setPosX(768);
	}

	for (int i = 0; i < getMapTilesCount(); i++) {
		// tile bounding
		int tileLeft = getMap()[i][0];
		int tileRight = getMap()[i][0] + width;
		int tileTop = getMap()[i][1];
		int tileBottom = getMap()[i][1] + height;
		int tileType = getMap()[i][2];

		if (tileType == 0) {
			// check if player is colliding with tile
			if ((playerRight >= tileLeft) && (playerLeft <= tileRight) && (playerBottom >= tileTop) && (playerTop <= tileBottom)) {
				// check if player is colliding with tile from the top
				if (playerBottom - 1 <= tileTop) {
					setPosY(tileTop - height);
					isOnGround = true;
					isJumping = false;
				}
				// check if player is colliding with tile from the bottom
				else if (playerTop + 1 >= tileBottom) {
					setPosY(tileBottom);
				}
				// check if player is colliding with tile from the left
				else if ((playerRight - 1 >= tileLeft) && lookingRight == false) {
					setPosX(tileLeft + width);
				}
				// check if player is colliding with tile from the right
				else if ((playerLeft + 1 <= tileRight) && lookingRight == true) {
					setPosX(tileRight - (width * 2));
				}
			}
		} else if (tileType == 1) {
			// gain health if player colliding with health tile
			if ((playerRight >= tileLeft) && (playerLeft <= tileRight) && (playerBottom >= tileTop) && (playerTop <= tileBottom)) {
				playerHealth(1);
				getMap()[i][2] = 50;
			}
		}
	}
}

void Player::playerHealth(int health) {
	if (this->health < this->max_health) {
		this->health = this->health + health;
	}
};

void Player::setHealthbar() {
	// set healthbar with full hearts and empty hearts
	for (int i = 0; i < this->max_health; i++) {
		if (i < getHealth()) {
			putimage(10 + (i * 30), 10, playerFullHeart, COPY_PUT);
		} else {
			putimage(10 + (i * 30), 10, playerEmptyHeart, COPY_PUT);
		}
	}
}

bool Player::playerTouchEnemy() {
    for(int i = 0; i < getEnemiesCount(); i++) {
        if(x + 32 >= getEnemies()[i].posX() && x <= getEnemies()[i].posX() + 32 && y + 32 >= getEnemies()[i].posY() && y <= getEnemies()[i].posY() + 32) {
            return true;
        }
    }
    return false;
}

void Player::registerTouchCount() {
	if(playerTouchEnemy() == 1) {
		setTouchCount(1);
	}
	else {
		if (getTouchCount() > 0)
			setTouchCount(-1);
	}
}